<div class="col-sm-6 col-md-5 col-md-offset-1">
  <div class="thumbnail">
    <img src="img/portofolio/ai_stardust.jpg" alt="">
    <div class="caption">
    <h3>Tracing - Stardust Dragon</h3>
    <p class="portofolioparagraf">Sebuah hasil karya tracing sebuah gambar dengan memanfaatkan tool bernama pentool yang terdapat pada adobe illustrator. karya ini merupakan sebuah tugas saat masih belajar di perguruan tinggi.</p>
    <p>
      <span class="label label-info">Adobe Illustrator</span>
    </p>
    
    </div>
  </div>
</div>